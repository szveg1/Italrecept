#ifndef TESZTEK_H
#define TESZTEK_H

void test();

#endif // TESZTEK_H